<?php
session_start();

if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
    		header("Location: ../control/logout.php");
		}else{
			echo "";
		}

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/buscaGeral.css">
	<title>Busca Geral</title>
	<meta charset="UTF-8">
	<script>
		function filtrar(m,n,c,f) {
		    if (m == "" && n == "" && c =="") {
		        document.getElementById("mostraTenis").innerHTML = "";
		        return;
		    } else {
		        if (window.XMLHttpRequest) {
		            // code for IE7+, Firefox, Chrome, Opera, Safari
		            xmlhttp = new XMLHttpRequest();
		        } else {
		            // code for IE6, IE5
		            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		        }
		        xmlhttp.onreadystatechange = function() {
		            if (this.readyState == 4 && this.status == 200) {



		                for (var i = 0; i < 1; i++) {
		                	var txt = this.responseText;
		                }




		                document.getElementById("mostraTenis").innerHTML = txt;
		            }
		        };
		        xmlhttp.open("GET","../control/tenisControl.php?acao=2&m="+m+"&n="+n+"&c="+c+"&f="+f,true);
		        xmlhttp.send();
    }
}

function Filtro(){
	var marca = document.getElementById("selectMarca");
	var numeracao = document.getElementById("selectNumeracao");
	var cor = document.getElementById("selectCor");
	var filtro = document.getElementById("selectFiltros");

	var m = marca.options[marca.selectedIndex].id;
	var n = numeracao.options[numeracao.selectedIndex].id;
	var c = cor.options[cor.selectedIndex].id;
	var f = filtro.options[filtro.selectedIndex].id;


	filtrar(m,n,c,f);
}

	</script>
</head>
<body onload="Filtro()">

<div class="maior">
	<div class="cabecalho">	<div class="logo"><a href="buscaGeral.php" class="cabecao">SNKR</a></div>
	<div class="login">
		<span class="middle">
			<?php
				if(isset($_SESSION['userloggedin']) && $_SESSION["userloggedin"] == true){
		    		echo "<a class='loginestilo' href='options.php'>".$_SESSION["login"]."</a>";
				}else{
					echo "<a class='loginestilo' href='../view/loginCliente.php'> Login </a>";
				}
			?>
		</span>
	</div>
	<div class="carrinho">
		<a href="../view/carrinho.php" class="carrinhoestilo">Carrinho</a>
	</div>
	</div>
	<div class="formselect">
		<div class="dentro">
		<form name= "select">
			Marca:
			<br>
			<select name="selectMarca" id="selectMarca" onchange="Filtro()" class="focta">
			<option id="marca is not null">Qualquer</option>
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $dados=$o->ListaMarca();
			         foreach ($dados as $marca)
			         	echo "<option id=\"marca='".$marca["marca"]."'\" value='".$marca["idTenis"]."'>".
			         	$marca["marca"]."</option>";
				?>
			</select>
			<br>
			Numeração:
			<br>
			<select name="selectNumeracao" id="selectNumeracao" onchange="Filtro()" class="focta">
			<option id="numeracao is not null">Qualquer</option>
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $dados=$o->ListaNumeracao();
			         foreach ($dados as $numeracao)
			         	echo "<option id=\"numeracao='".$numeracao["numeracao"]."'\" value='".$numeracao["idTenis"]."'>".
			         	$numeracao["numeracao"]."</option>";
				?>
			</select>
			<br>
			Cor:
			<br>
			<select name="selectCor" id="selectCor" onchange="Filtro()" class="focta">
			<option id="cor is not null">Qualquer</option>
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $dados=$o->ListaCor();
			         foreach ($dados as $cor)
			         	echo "<option id=\"cor='".$cor["cor"]."'\" value='".$cor["idTenis"]."'>".
			         	$cor["cor"]."</option>";
				?>
			</select>
			<br>
			Filtrar por:
			<br>
			<select id="selectFiltros" onchange="Filtro()" class="focta">
				<option id="idTenis">Recomendados</option>
				<option id="preco asc">Menor Preco</option>
				<option id="preco desc">Maior Preco</option>
			</select>
			<!--<input type="hidden" name="acao" value="2">-->
		</form>
		</div>
	</div>



	<br> <br>

	<div id="mostraTenis" class="mostraTenis"></div>
</div>
</body>
</html>
