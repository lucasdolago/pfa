<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="../css/infoTenis.css">
</head>
<body>
	<div class="cabecalho">
		<div class="logo">
			<a href="buscaGeral.php" class="cabecao">SNKR</a>
		</div>
	</div>

	<div class="container">
		<div id="foto" class="fotoTenis">
			<?php
				require_once '../dao/TenisDao.php';
		        $o=new TenisDAO();
		        $id=$_GET["t"];
		        $dados=$o->ListaTenis($id);
		        foreach ($dados as $dados)
		        	echo "<img class='fotoDoTenis' src='../img/".$dados["nomeFoto"]."'>";
			?>
		</div>

		<div class="informacoesTenis">

			<div id="marca" class="nomeMarca">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
			        	echo $dados["marca"];
				?>
			</div>
			<div id="modelo" class="nomeModelo">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
			        	echo $dados["modelo"];
				?>
			</div>

			<div id="preco" class="valorPreco">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
			        	echo "R$".$dados["preco"];
				?>
			</div>

			<div id="numero" class="valorNumero">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
			        	echo "<div class='textoNumeracao'>Numeração:</div> ".$dados["numeracao"];
				?>
			</div>
			<div id="descricao" class="campoDesc">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
			        	echo "<div class='textoDesc'> Descrição: </div> ".$dados["descricao"];
				?>
			</div>

			<div id="comprar" class="buttonComprar">
				<?php
					require_once '../dao/TenisDao.php';
			        $o=new TenisDAO();
			        $id=$_GET["t"];
			        $dados=$o->ListaTenis($id);
			        foreach ($dados as $dados)
						echo "<a class='linkComprar' href='addCarrinho.php?t=".$dados["idTenis"]."'>Comprar</a>";
				?>
			</div>
			<div class="buttonVoltarLoja">
				<a href="../view/buscaGeral.php" class="linkVoltarLoja">Voltar para a loja</a>
			</div>
		</div>
	</div>
</body>
</html>
