<?php
session_start();
if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginAdministrador.php");
		}
		$id = $_GET["id"];
?>
<html>
	<head>
	<title>Atualizar Tênis</title>
	</head>
<body>
	<h2>Atualizar Tenis</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/tenisControl.php?id=<?php echo $id?>">
				<?php
				require_once '../dao/TenisDao.php';
				$dao= new TenisDao();
				$dados=$dao->ListaTenis($id);
				foreach ($dados as $p){
			?>
	Marca: <input type="text" name="marca" value="<?php echo $p['marca']?>"><br><br>
	Modelo: <input type="text" name="modelo" value="<?php echo $p['modelo']?>"><br><br>
	Numeração: <input type="number" name="numeracao" value="<?php echo $p['numeracao']?>"><br><br>
	Cor: <input type="text" name="cor" value="<?php echo $p['cor']?>"><br><br>
	Preço: <input type="number" name="preco" value="<?php echo $p['preco']?>"><br><br>
	Descrição: <input type="text" name="descricao" value="<?php echo $p['descricao']?>"><br><br>
	Status: <input type="text" name="status" value="<?php echo $p['status']?>"><br><br>
	<img src="../img/<?php echo $p['nomeFoto']?>" width="100" height="100"> <br>
	Foto: <br><input type="file" name="foto" value=""><br><br>
	<?php } ?>
	<input type="submit" name="Atualizar">
	<input type="hidden" name="acao" value="6">
</form>
<p><a href="mainAdministrador.php">Voltar para pagina do admin</a></p>
</body>
</html>


