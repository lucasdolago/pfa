<?php
session_start();

if(isset($_SESSION['userloggedin']) && $_SESSION["userloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginCliente.php");
		}
error_reporting(E_ERROR | E_PARSE);


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table width="100%" border="1">
		<tr bgcolor="#CCC">
			<td>Marca</td>	
			<td>Modelo</td>
			<td>Numero</td>
			<td>Cor</td>	
			<td>Preco</td>
			<td>Opçoes</td>
		</tr>
		<?php
			require_once '../dao/TenisDao.php';
	        $o=new TenisDAO();
	        $ids=implode(',', $_SESSION["cart"]);
	        $dados=$o->ListaTenis($ids);
	        foreach ($dados as $dados){
		?>
		<tr>
			<td><?php echo $dados["marca"]?></td>	
			<td><?php echo $dados["modelo"]?></td>
			<td><?php echo $dados["numeracao"]?></td>
			<td><?php echo $dados["cor"]?></td>
			<td><?php echo $dados["preco"]?></td>
			<td> 
			<a href="../control/tenisControl.php?acao=3&id=<?php echo $dados["idTenis"]?>">Retirar</a>
			</td>	
		</tr>
		<?php }?>
	</table>
	<a href="../control/vendaControl.php?acao=1">Finalizar venda</a>
	<a href="buscaGeral.php">Continuar comprando</a>
</body>
</html>

	        	