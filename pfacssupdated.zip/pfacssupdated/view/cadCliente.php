<html>
	<head>
	<meta charset="UTF-8">
	<title>Cadastro de Cliente</title>
	<script>
		function validate(){

            var password = document.getElementById("password").value;
            var cPassword = document.getElementById("confirmPassword").value;
          	var v = document.getElementById("validation");
            if (password!=cPassword) {
               v.innerHTML = "As senhas não coincidem!";
               return false;
               
            }else{
            	return true;
            }
        }
	</script>
	</head>
<body>
	<h2>Cadastro de Cliente</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/clienteControl.php" onsubmit="return validate();">
	Nome: <input type="text" name="nome" pattern="[a-zA-Z]+" title="Name | Only Letters" required><br><br>
	Sobrenome: <input type="text" name="sobrenome" pattern="[a-zA-Z]+" title="Last Name | Only Letters" required><br><br>
	Endereço: <input type="text" name="endereco" required><br><br>
	Email: <input type="email" name="email" required><br><br>
	Login: <input type="text" name="login" required><br><br>
	Senha: <input type="password" name="senha" id="password" required><br><br>
	Confirme sua senha: <input type="password" name="confirmaSenha" id="confirmPassword" required><br><br>
	<div id="validation" style="color: red;"></div>
	<input type="submit" name="Cadastrar">
	<input type="hidden" name="acao" value="1">
</form>
</body>
</html>