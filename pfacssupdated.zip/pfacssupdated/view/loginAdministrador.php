<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<title>Login</title>
</head>
<body>
	Administrador
	<form name= "loginAdministrador" method="post" enctype="multipart/form-data" action="../control/loginControl.php">
		Login: <input type="text" placeholder="Login" name="login"><br>
		Senha: <input type="password" placeholder="********" name="senha"> <br>
		<input type="submit" value="Entrar">
		<input type="hidden" name="acao" value="2">
	</form>
</body>
</html>