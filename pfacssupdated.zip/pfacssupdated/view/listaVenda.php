<?php 
session_start();

if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
			echo "";
		}else{
			header("Location: loginAdministrador.php");
		}

?>

<!DOCTYPE html>
<html>
<head>
	<title>LISTA DE VENDAS</title>
</head>
<body>
	<table width="100%" border="1">
			<tr bgcolor="#CCC">
				<td>Id da venda</td>	
				<td>Id do cliente</td>
				<td>Data</td>
				<td>Hora</td>	
				<td>Total</td>			
			</tr>
			<?php
				require_once '../dao/vendaDao.php';
				$dao= new vendaDao();
				$dados=$dao->ListaGeral();
				foreach ($dados as $p){
			?>
			<tr>
				<td><?php echo $p["idVenda"]?></td>	
				<td><?php echo $p["idCliente"]?></td>
				<td><?php echo $p["data"]?></td>
				<td><?php echo $p["hora"]?></td>
				<td><?php echo $p["total"]?></td>
			</tr>
			<?php }?>
		</table>
		<p><a href="mainAdministrador.php">Voltar para pagina do admin</a></p>
</body>
</html>