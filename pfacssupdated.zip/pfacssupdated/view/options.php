<?php
session_start();
if(isset($_SESSION['userloggedin']) && $_SESSION["userloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginCliente.php");
		}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>CLIENTE</title>
</head>
<body>
	<p>OLÁ, <?php echo $_SESSION["login"]; ?></p>
	<p><a href="alterarCliente.php?id=<?php echo $_SESSION['id'] ?>">Alterar informacoes</a> <a href="../view/carrinho.php">Ver carrinho</a> <a href="../control/logout.php">Logout</a></p>
	<p><a href="buscaGeral.php">Voltar a pagina principal</a></p>
</body>
</html>