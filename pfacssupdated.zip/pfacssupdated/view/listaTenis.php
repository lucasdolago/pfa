<?php 
session_start();

if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
			echo "";
		}else{
			header("Location: loginAdministrador.php");
		}

?>

<!DOCTYPE html>
<html>
<head>
	<title>LISTA DE TENIS</title>
</head>
<body>
	<table width="100%" border="1">
			<tr bgcolor="#CCC">
				<td>Id do Tenis</td>	
				<td>Marca</td>
				<td>Modelo</td>
				<td>Numero</td>	
				<td>Cor</td>
				<td>Preco</td>
				<td colspan="2">Opcoes</td>			
			</tr>
			<?php
				require_once '../dao/TenisDao.php';
				$dao= new TenisDao();
				$dados=$dao->ListaGeral();
				foreach ($dados as $p){
			?>
			<tr>
				<td><?php echo $p["idTenis"]?></td>	
				<td><?php echo $p["marca"]?></td>
				<td><?php echo $p["modelo"]?></td>
				<td><?php echo $p["numeracao"]?></td>
				<td><?php echo $p["cor"]?></td>
				<td><?php echo $p["preco"]?></td>
				<td> 
				<a href="../control/tenisControl.php?acao=5&id=<?php echo $p["idTenis"] ?>">Excluir</a>
				</td>
				<td> 
				<a href="alterarTenis.php?id=<?php echo $p["idTenis"]?>">Alterar</a>
				</td>	
			</tr>
			<?php }?>
		</table>
		<p><a href="mainAdministrador.php">Voltar para pagina do admin</a></p>
</body>
</html>