<?php 
session_start();

if (empty($_SESSION["cart"])){
	$_SESSION["cart"] = array();
}

if(isset($_SESSION['userloggedin']) && $_SESSION["userloggedin"] == true){
    		array_push($_SESSION["cart"], $_GET["t"]);
		}else{
			header("Location: ../view/loginCliente.php");
		}




 ?>

 <p> O PRODUTO FOI ADICIONADO AO CARRINHO!</p>
 <p><a href="buscaGeral.php">Continuar comprando</a> <a href="carrinho.php">Ver carrinho</a></p>