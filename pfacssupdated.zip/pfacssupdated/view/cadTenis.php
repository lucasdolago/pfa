<?php
session_start();
if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginAdministrador.php");
		}
?>
<html>
	<head>
	<meta charset="UTF-8">
	<title>Cadastro de Tênis</title>
	</head>
<body>
	<h2>Cadastro de Tênis</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/tenisControl.php">
	Marca: <input type="text" name="marca" required><br><br>
	Modelo: <input type="text"  name="modelo" required><br><br>
	Numeração: <input type="number" name="numeracao" min="34" max="45" required><br><br>
	Cor: <input type="text" name="cor" required><br><br>
	Preço: <input type="number" name="preco" step="any" min="0" required><br><br>
	Descrição: <input type="text" name="descricao" required><br><br>
	Status: <input type="text" name="status" required><br><br>
	Foto: <br><input type="file" name="foto" multiple required><br><br>
	<input type="submit" name="Cadastrar">
	<input type="hidden" name="acao" value="1">
</form>
<p><a href="mainAdministrador.php">Voltar para pagina do admin</a></p>
</body>
</html>

