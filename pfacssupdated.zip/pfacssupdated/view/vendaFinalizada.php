<!DOCTYPE html>
<html>
<head>
	<title>VENDA FINALIZADA</title>
</head>
<body>
	<p>PARABÉNS! SUA VENDA FOI FINALIZADA COM SUCESSO!</p>
	<p><a href="buscaGeral.php">Voltar a loja</a> <a href="../control/logout.php">Logout</a></p>
</body>
</html>