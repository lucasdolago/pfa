<?php
session_start();
if(isset($_SESSION['userloggedin']) && $_SESSION["userloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginCliente.php");
		}
		$id = $_GET["id"];
?>
<html>
	<head>
	<title>Atualizacao de cliente</title>
	</head>
<body>
	<h2>Atualizacao de cliente</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/clienteControl.php?id=<?php echo $id?>">
	<?php
				require_once '../dao/ClienteDao.php';
				$dao= new ClienteDao();
				$dados=$dao->Lista($id);
				foreach ($dados as $p){
			?>
	Nome: <input type="text" name="nome" value="<?php echo $p['nome']?>"><br><br>
	Endereço: <input type="text" name="endereco" value="<?php echo $p['endereco']?>"><br><br>
	Email: <input type="email" name="email" value="<?php echo $p['email']?>"><br><br>
	Login: <input type="text" name="login" value="<?php echo $p['login']?>"><br><br>
	Senha: <input type="password" name="senha" value="<?php echo $p['senha']?>"><br><br>
	<?php }?>
	<input type="submit" name="Atualizar">
	<input type="hidden" name="acao" value="2">
</form>
<p><a href="options.php">Voltar para pagina do cliente</a></p>
</body>
</html>