<?php
session_start();
if(isset($_SESSION['adminloggedin']) && $_SESSION["adminloggedin"] == true){
    		echo "";
		}else{
			header("Location: ../view/loginAdministrador.php");
		}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMINISTRADOR</title>
</head>
<body>
	<p>BEM VINDO, <?php echo $_SESSION["login"]; ?></p>
	<p><a href="cadTenis.php">Cadastrar tenis</a> <a href="listaTenis.php">Listar Tenis</a> <a href="listaVenda.php"> Listar Vendas</a> <a href="../control/logout.php">Logout</a></p>
</body>
</html>