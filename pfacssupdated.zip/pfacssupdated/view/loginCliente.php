<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Login</title>
</head>
<body>
	Usuário
	<form name= "loginCliente" method="post" enctype="multipart/form-data" action="../control/loginControl.php">
		Login: <input type="text" placeholder="Login" name="login"><br>
		Senha: <input type="password" placeholder="********" name="senha"> <br>
		<div id="validation"></div>
		<a href="loginAdministrador.php">Entrar como administrador</a><br>
		<a href="cadCliente.php">Criar conta</a><br>
		<input type="submit" value="Entrar">
		<input type="hidden" value="1" name="acao">
	</form>
</body>
</html>