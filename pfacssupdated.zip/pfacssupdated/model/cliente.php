<?php
class Cliente{
		private $idCliente;
		private $nome;
		private $endereco;
		private $email;
		private $login;
		private $senha;

		function setIdCliente($id){
			$this->idCliente=$id;
		}

		function setNome($nome){
			$this->nome=$nome;
		}

		function setEndereco($endereco){
			$this->endereco=$endereco;
		}

		function setEmail($email){
			$this->email=$email;
		}

		function setLogin($login){
			$this->login=$login;
		}

		function setSenha($senha){
			$this->senha=$senha;
		}


		function getIdCliente(){
			return $this->idCliente;
		}

		function getNome(){
			return $this->nome;
		}

		function getEndereco(){
			return $this->endereco;
		}

		function getEmail(){
			return $this->email;
		}

		function getLogin(){
			return $this->login;
		}

		function getSenha(){
			return $this->senha;
		}

	}

?>