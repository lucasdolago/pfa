<?php 
	class Tenis{
		private $idTenis;
		private $marca;
		private $modelo;
		private $numeracao;
		private $cor;
		private $preco;
		private $descricao;
		private $nomeFoto;
		private $status;

		function setIdTenis($id){
			$this->idTenis=$id;
		}

		function setMarca($marca){
			$this->marca=$marca;
		}

		function setModelo($modelo){
			$this->modelo=$modelo;
		}

		function setNumeracao($numeracao){
			$this->numeracao=$numeracao;
		}

		function setCor($cor){
			$this->cor=$cor;
		}

		function setPreco($preco){
			$this->preco=$preco;
		}

		function setDescricao($descricao){
			$this->descricao=$descricao;
		}

		function setNomeFoto($nomeFoto){
			$this->nomeFoto=$nomeFoto;
		}

		function setStatus($status){
			$this->status=$status;
		}

		
		function getIdTenis(){
			return $this->idTenis;
		}

		function getMarca(){
			return $this->marca;
		}

		function getModelo(){
			return $this->modelo;
		}

		function getNumeracao(){
			return $this->numeracao;
		}

		function getCor(){
			return $this->cor;
		}

		function getPreco(){
			return $this->preco;
		}

		function getDescricao(){
			return $this->descricao;
		}

		function getNomeFoto(){
			return $this->nomeFoto;
		}

		function getStatus(){
			return $this->status;
		}
	}
?>