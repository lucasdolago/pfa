<?php
	require_once '../control/conexao.php';
class LoginDao{
	private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}

	function buscaLoginCliente($login,$senha){
		session_start(); 
		$sql =  "select * from cliente where login='".$login."' and senha='".$senha."'";
		try{
			$query=mysqli_query($this->con, $sql);
			$numrows = mysqli_num_rows($query);
			if($numrows == 1){
				while($row = mysqli_fetch_array($query)){ 
					$_SESSION["login"] = $row["login"]; 
					$_SESSION["userloggedin"] = true;
					$_SESSION["id"] = $row["idCliente"];
				}
				header("Location: ../view/buscaGeral.php");
			} else {
				header("Location: ../view/loginCliente.php");
			}
		}catch(mysqli_sql_exception $e){
			echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
		}
	}	


	function buscaLoginAdministrador($login,$senha){
		session_start(); 
		$sql =  "select * from administrador where login='".$login."' and senha='".$senha."'";
		try{
			$query=mysqli_query($this->con, $sql);
			$numrows = mysqli_num_rows($query);
			if($numrows == 1){  
				while($row = mysqli_fetch_array($query)){
					$_SESSION["login"] = $row["login"]; 
					$_SESSION["adminloggedin"] = true;
					$_SESSION["senha"] = $row["senha"];
					$_SESSION["id"] = $row["idAdministrador"];
				}
				header("Location: ../view/mainAdministrador.php");
			} else {
				header("Location: ../view/loginAdministrador.php");
			}
		}catch(mysqli_sql_exception $e){
			echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
		}
	}

}

 ?>