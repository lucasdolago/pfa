<?php
	require_once '../control/conexao.php';

	class TenisDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}

		function inserir(Tenis $t){
			$marca=$t->getMarca();
			$modelo=$t->getModelo();
			$numeracao=$t->getNumeracao();
			$cor=$t->getCor();
			$preco=$t->getPreco();
			$descricao=$t->getDescricao();
			$nomeFoto=$t->getNomeFoto();
			$status=$t->getStatus();

			$sql="insert into tenis (marca,modelo,numeracao,cor,preco,descricao,nomeFoto,status) values('".$marca."','".$modelo."','".$numeracao."','".$cor."','".$preco."','".$descricao."','".$nomeFoto."','".$status."')";
			echo "Tenis inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				header("Location: ../view/mainAdministrador.php");
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}

		function ListaMarca(){
			$dados=null;
			$sql="select distinct marca from tenis order by marca asc";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function ListaNumeracao(){
			$dados=null;
			$sql="select distinct numeracao from tenis order by numeracao asc";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function ListaCor(){
			$dados=null;
			$sql="select distinct cor from tenis order by cor asc";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function Filtra($m,$n,$c,$f){
			$dados=null;
			$vet=[];
			$sql= "select * from tenis where status=1 and ".$m." and ".$n." and ".$c." order by ".$f."";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}

			for ($i=0; $i < sizeof($vet) ; $i++) {
				echo "<div class='card'><a class='containerestilo' href='infoTenis.php?t=".$vet[$i]["idTenis"]."'><center><img src='../img/" .$vet[$i]["nomeFoto"] . "' style='width:90%;height:250px;'></center><div class='container'><h4>".$vet[$i]["marca"]." ".$vet[$i]["modelo"]."</h4><p> R$".$vet[$i]["preco"]."</p></a></div>     </div>";
			}


			return $vet;
		}

		function ListaTenis($id){
			$dados=null;
			$vet=[];
			$sql="select * from tenis where idTenis IN (".$id.")";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function ListaGeral(){
			$dados=null;
			$vet=[];
			$sql="select * from tenis where status=1";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function excluir($id){
         $retorno=false;
         $sql="update tenis set status=0 where idTenis= ".$id;
         try{
            mysqli_query($this->con, $sql) or die ("Erro ao excluir partido<hr>".mysqli_error($this->con));
            $retorno=true;
         }catch(mysqli_sql_exception $e){
            echo "Erro ao excluir partido";
         }
         return $retorno;
      }

		function insereVendaCarrinho(){
			date_default_timezone_set('America/Sao_Paulo');
			$date = date('Y-m-d h:i:s');
			$date = date('Y-m-d', strtotime($date));
			$time = date('H:i:s');
			$idCli = $_SESSION["id"];
			$total =0;
			$o=new TenisDAO();
	        $ids=implode(',', $_SESSION["cart"]);
	        $dados=$o->ListaTenis($ids);
	        foreach ($dados as $dados){
	        	$total +=$dados["preco"];
	        }

	        $sql = "insert into venda (idCliente, data,hora,total) values ('".$idCli."','".$date."','".$time."','".$total."')";
	        try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				$lastId = mysqli_insert_id($this->con);
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}

			$o2=new TenisDAO();
	        $ids2=implode(',', $_SESSION["cart"]);
	        $dados2=$o->ListaTenis($ids2);
	        foreach ($dados2 as $dados){
	        	$sql2[]="('".$lastId."','".$dados["idTenis"]."')";
	        }

	        $sql3 = "insert into venda_has_tenis (idVenda, idTenis) values ".implode(',',$sql2);
	        try{
				mysqli_query($this->con, $sql3)or die(mysqli_error($this->con));
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}

			unset($_SESSION['cart']);

		}

		function alterar(Tenis $t,$id){
			$marca=$t->getMarca();
			$modelo=$t->getModelo();
			$numeracao=$t->getNumeracao();
			$cor=$t->getCor();
			$preco=$t->getPreco();
			$descricao=$t->getDescricao();
			$nomeFoto=$t->getNomeFoto();
			$status=$t->getStatus();
			if(!empty($nomeFoto)){
				$sql="update tenis set marca='".$marca."',modelo='".$modelo."'  ,numeracao='".$numeracao."'  ,cor='".$cor."'  ,preco='".$preco."' ,descricao='".$descricao."' , nomeFoto='".$nomeFoto."'  ,status=".$status." where idTenis=".$id;
			}
			else{
				$sql="update tenis set marca='".$marca."',modelo='".$modelo."'  ,numeracao='".$numeracao."'  ,cor='".$cor."'  ,preco='".$preco."' ,descricao='".$descricao."'  ,status=".$status." where idTenis=".$id;
			}

			echo "Tenis inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				header("Location: ../view/listaTenis.php");
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}


	}

?>
