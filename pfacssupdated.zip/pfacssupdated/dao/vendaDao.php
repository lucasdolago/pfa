<?php
	require_once '../control/conexao.php';
	require_once '../dao/TenisDao.php';
	
	class VendaDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}

		function insereVendaCarrinho(){
			date_default_timezone_set('America/Sao_Paulo');
			$date = date('Y-m-d h:i:s');
			$date = date('Y-m-d', strtotime($date));
			$time = date('H:i:s');
			$idCli = $_SESSION["id"];
			$total =0;
			$o=new TenisDAO();
	        $ids=implode(',', $_SESSION["cart"]);
	        $dados=$o->ListaTenis($ids);
	        foreach ($dados as $dados){		
	        	$total +=$dados["preco"];
	        }

	        $sql = "insert into venda (idCliente, data,hora,total) values ('".$idCli."','".$date."','".$time."','".$total."')";
	        try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				$lastId = mysqli_insert_id($this->con);
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}

			$o2=new TenisDAO();
	        $ids2=implode(',', $_SESSION["cart"]);
	        $dados2=$o->ListaTenis($ids2);
	        foreach ($dados2 as $dados){		
	        	$sql2[]="('".$lastId."','".$dados["idTenis"]."')";
	        }

	        $sql3 = "insert into venda_has_tenis (idVenda, idTenis) values ".implode(',',$sql2);
	        try{
				mysqli_query($this->con, $sql3)or die(mysqli_error($this->con));
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}

			unset($_SESSION['cart']);

		}

		function ListaGeral(){
			$dados=null;
			$vet=[];
			$sql="select * from venda";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}	
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}





	}
?>