<?php 
	require_once '../control/conexao.php';
	class AdministradorDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}
		function inserir(Administrador $a){
			$email=$a->getEmail();
			$login=$a->getlogin();
			$senha=$a->getsenha();

			$sql="insert into administrador (email,login,senha) values('".$email."','".$login."','".$senha."')";
			//echo "Cliente inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				header("Location: ../view/loginAdministrador.php");
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}
	}
?>