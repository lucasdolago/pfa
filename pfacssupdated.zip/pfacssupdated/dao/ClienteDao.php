<?php 
	require_once '../control/conexao.php';
	class ClienteDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}

		function inserir(Cliente $c){
			$nome=$c->getNome();
			$endereco=$c->getEndereco();
			$email=$c->getEmail();
			$login=$c->getlogin();
			$senha=$c->getsenha();

			$sql="insert into cliente (nome,endereco,email,login,senha) values('".$nome."','".$endereco."','".$email."','".$login."','".$senha."')";
			//echo "Cliente inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
				header("Location: ../view/loginCliente.php");
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}

			function alterar(Cliente $c){
			$id = $_GET['id'];
			$nome=$c->getNome();
			$endereco=$c->getEndereco();
			$email=$c->getEmail();
			$login=$c->getlogin();
			$senha=$c->getsenha();

			$sql="update cliente set nome='".$nome."',endereco='".$endereco."'  ,email='".$email."'  ,login='".$login."'  ,senha='".$senha."' where idCliente=".$id;
				try{
					mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
					header("Location: ../view/options.php");
				}catch(mysqli_sql_exception $e){
					echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
				}
			}

			function Lista($id){
			$dados=null;
			$vet=[];
			$sql="select * from cliente where idCliente=".$id;
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}	
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		}
?>
