-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 06/11/2017 às 16:52
-- Versão do servidor: 5.5.50-0ubuntu0.14.04.1
-- Versão do PHP: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `pfa`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `administrador`
--

CREATE TABLE IF NOT EXISTS `administrador` (
  `idAdministrador` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`idAdministrador`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Fazendo dump de dados para tabela `administrador`
--

INSERT INTO `administrador` (`idAdministrador`, `login`, `senha`, `email`) VALUES
(1, 'dolagoxd', 'dolago2k00', 'dolagoxd@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `endereco` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Fazendo dump de dados para tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nome`, `email`, `endereco`, `login`, `senha`) VALUES
(1, 'Lucas', 'ifprlucas@gmail.com', 'rua paranapanema, 212', 'dolago', 'dolago2k00'),
(2, '', 'dolagoxd@gmail.com', '', 'dolagoxd', 'dolago2k00'),
(3, '', 'dolagoxd@gmail.com', '', 'dolagoxd', 'dolago2k00'),
(4, 'Mario', 'mariosergio@live.com', 'Rua Amazonas', 'marinho', 'marinho123'),
(5, 'Anderson', 'anderson@gmail.com', 'rua araguaia', 'anderson', 'anderson2k00'),
(6, 'Itamar', 'itamarnieradka@gmail.com', 'Avenida Araucaria, 680', 'itamar', 'itamar');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tenis`
--

CREATE TABLE IF NOT EXISTS `tenis` (
  `idTenis` int(11) NOT NULL AUTO_INCREMENT,
  `marca` varchar(45) NOT NULL,
  `modelo` varchar(45) NOT NULL,
  `numeracao` int(11) NOT NULL,
  `cor` varchar(45) NOT NULL,
  `preco` float NOT NULL,
  `descricao` varchar(45) NOT NULL,
  `nomeFoto` varchar(100) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idTenis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Fazendo dump de dados para tabela `tenis`
--

INSERT INTO `tenis` (`idTenis`, `marca`, `modelo`, `numeracao`, `cor`, `preco`, `descricao`, `nomeFoto`, `status`) VALUES
(6, 'nike', 'airforce', 38, 'preto', 420, 'nike airforce preto numero 38', 'airforcePreto.jpg', 0),
(7, 'adidas', 'baixissimo', 41, 'vermelho', 321, 'adidas baixo vermelho 41', 'adidasVermelho.jpg', 1),
(8, 'supra', 'suprao', 38, 'branco', 678, 'supra branco 38', 'supraBranco.jpg', 1),
(9, 'nike', 'airforce', 41, 'branco', 560, 'airforce branco numero 41', 'airforceBranco.jpg', 1),
(10, 'adidas', 'nmdr1', 37, 'preto', 480, 'adidas nmd 37', 'adidasPreto.jpg', 1),
(11, 'supra', 'red', 39, 'vermelho', 540, 'supra red 39', 'supraVermelho.jpg', 1),
(12, 'nike', 'shox', 40, 'azul', 400, 'nike shox azul numero 40', 'shoxAzul.jpg', 1),
(13, 'nike', 'janoski', 36, 'verde', 370, 'janoski verde 36', 'janoskiVerde.jpg', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `venda`
--

CREATE TABLE IF NOT EXISTS `venda` (
  `idVenda` int(11) NOT NULL AUTO_INCREMENT,
  `idCliente` int(11) NOT NULL,
  `data` date NOT NULL,
  `hora` time NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY (`idVenda`),
  KEY `fk_idCliente` (`idCliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Fazendo dump de dados para tabela `venda`
--

INSERT INTO `venda` (`idVenda`, `idCliente`, `data`, `hora`, `total`) VALUES
(1, 1, '2017-11-06', '15:55:27', 861),
(2, 5, '2017-11-06', '16:28:40', 721),
(3, 6, '2017-11-06', '16:35:13', 1078);

-- --------------------------------------------------------

--
-- Estrutura para tabela `venda_has_tenis`
--

CREATE TABLE IF NOT EXISTS `venda_has_tenis` (
  `idVendaTenis` int(11) NOT NULL AUTO_INCREMENT,
  `idVenda` int(11) NOT NULL,
  `idTenis` int(11) NOT NULL,
  PRIMARY KEY (`idVendaTenis`),
  KEY `fk_idVenda` (`idVenda`),
  KEY `fk_idTenis` (`idTenis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Fazendo dump de dados para tabela `venda_has_tenis`
--

INSERT INTO `venda_has_tenis` (`idVendaTenis`, `idVenda`, `idTenis`) VALUES
(1, 1, 7),
(2, 1, 11),
(3, 2, 7),
(4, 2, 12),
(5, 3, 8),
(6, 3, 12);

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `fk_idCliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`);

--
-- Restrições para tabelas `venda_has_tenis`
--
ALTER TABLE `venda_has_tenis`
  ADD CONSTRAINT `fk_idTenis` FOREIGN KEY (`idTenis`) REFERENCES `tenis` (`idTenis`),
  ADD CONSTRAINT `fk_idVenda` FOREIGN KEY (`idVenda`) REFERENCES `venda` (`idVenda`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
