<?php
   class Conexao{
   	private $con;
   	function conectar(){
   		$this->con=null;
   		try{
   		   $this->con=mysqli_connect("localhost","root","","pfa");
   		}catch(mysqli_sql_exception $e){
   			echo $e->getMessage();
   		}
   		return $this->con;
   	}
   	function desconectar(){
   		mysqli_close($this->con);
   	}
   }
?>
