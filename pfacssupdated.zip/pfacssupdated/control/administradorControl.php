<?php
	require_once '../model/administrador.php';
	require_once '../dao/AdministradorDao.php';

	class AdministradorControl{
		private $acao;
		function __construct(){
			$this->acao=$_POST["acao"];
			$this->verificaAcao($this->acao);
		}
		function verificaAcao($acao){
			switch ($acao){
				case 1:
					$a=new Administrador();
					$a->setEmail($_POST["email"]);
					$a->setLogin($_POST["login"]);
					$a->setSenha($_POST["senha"]);
					$dao = new AdministradorDao();
					$dao->inserir($a);
				break;
			}
		}
	}
	new AdministradorControl();
?>