<?php
	require_once '../model/cliente.php';
	require_once '../dao/ClienteDao.php';

	class ClienteControl{
		private $acao;
		function __construct(){
			if(isset($_POST["acao"]))
   		   	 	$this->acao=$_POST["acao"];
			else
           		$this->acao=$_GET["acao"];
            	$this->verificaAcao();
            	

			$o = new Conexao();
			$this->con=$o->conectar();
		}
		function verificaAcao(){
			switch ($this->acao){
				case 1:
					$fullname = $_POST["nome"]." ".$_POST["sobrenome"];
					$c=new Cliente();
					$c->setNome($fullname);
					$c->setEndereco($_POST["endereco"]);
					$c->setEmail($_POST["email"]);
					$c->setLogin($_POST["login"]);
					$c->setSenha($_POST["senha"]);
					$dao = new ClienteDao();
					$dao->inserir($c);
				break;
				case 2:
					$id = $_GET['id'];
					$fullname = $_POST["nome"]." ".$_POST["sobrenome"];
					$c=new Cliente();
					$c->setNome($fullname);
					$c->setEndereco($_POST["endereco"]);
					$c->setEmail($_POST["email"]);
					$c->setLogin($_POST["login"]);
					$c->setSenha($_POST["senha"]);
					$dao = new ClienteDao();
					$dao->alterar($c);
				break;
			}
		}
	}
	new ClienteControl();
?>