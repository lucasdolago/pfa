<?php
	session_start();
	
?>
<?php
	require_once '../model/tenis.php';
	require_once '../dao/TenisDao.php';
	require_once '../control/conexao.php';
	class TenisControl{
		private $acao;
		private $con;
		function __construct(){

			if(isset($_POST["acao"]))
   		   	 	$this->acao=$_POST["acao"];
			else
           		$this->acao=$_GET["acao"];
            	$this->verificaAcao();
            	

			$o = new Conexao();
			$this->con=$o->conectar();
  		}
			
		function verificaAcao(){
			switch ($this->acao){
				case 1:
					$foto=$_FILES["foto"];
  					move_uploaded_file($foto["tmp_name"], "../img/".$foto["name"]);
					$t=new Tenis();
					$t->setMarca($_POST["marca"]);
					$t->setModelo($_POST["modelo"]);
					$t->setNumeracao($_POST["numeracao"]);
					$t->setCor($_POST["cor"]);
					$t->setPreco($_POST["preco"]);
					$t->setDescricao($_POST["descricao"]);
					$t->setNomeFoto($_FILES["foto"]["name"]);
					$t->setStatus($_POST["status"]);
					$dao = new TenisDao();
					$dao->inserir($t);
				break;
				case 2:
					$m = $_GET["m"];
					$n = $_GET["n"];
					$c = $_GET["c"];
					$f = $_GET["f"];
					$dao = new TenisDao();
					$dao->Filtra($m,$n,$c,$f);
					//header('Location: ../view/buscaGeral.php');
				break;
				case 3:	
					$id = $_GET["id"];
					$_SESSION["cart"] = array_diff($_SESSION["cart"], [$id]);
					header('Location: ../view/carrinho.php');
				break;
				case 4:
					$dao = new TenisDao();
					$dao->insereVendaCarrinho();
					header('Location: ../view/vendaFinalizada.php');
				break;
				case 5:
					$id = $_GET["id"];
					$dao = new TenisDao();
					$dao->excluir($id);
					header("Location: ../view/listaTenis.php");
				break;
				case 6:
					$id = $_GET["id"];
					$foto=$_FILES["foto"];
  					move_uploaded_file($foto["tmp_name"], "../img/".$foto["name"]);
					$t=new Tenis();
					$t->setMarca($_POST["marca"]);
					$t->setModelo($_POST["modelo"]);
					$t->setNumeracao($_POST["numeracao"]);
					$t->setCor($_POST["cor"]);
					$t->setPreco($_POST["preco"]);
					$t->setDescricao($_POST["descricao"]);
					$t->setNomeFoto($_FILES["foto"]["name"]);
					$t->setStatus($_POST["status"]);
					$dao = new TenisDao();
					$dao->alterar($t,$id);
				break;
			}
		}
	}
	new TenisControl();
?>