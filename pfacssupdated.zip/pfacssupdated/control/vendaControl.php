<?php
 	session_start();

	require_once '../dao/vendaDao.php';
	require_once '../control/conexao.php';

	class VendaControl{
		private $acao;
		private $con;
		function __construct(){

			if(isset($_POST["acao"]))
   		   	 	$this->acao=$_POST["acao"];
			else
           		$this->acao=$_GET["acao"];
            	$this->verificaAcao();
            	

			$o = new Conexao();
			$this->con=$o->conectar();
  		}
			
		function verificaAcao(){
			switch ($this->acao){
				case 1:
					$dao = new VendaDao();
					$dao->insereVendaCarrinho();
					header('Location: ../view/vendaFinalizada.php');
				break;
				case 2:
					
				break;
			}
		}
	}
	new VendaControl();
?>