<?php
 	session_start();

	require_once '../dao/loginDao.php';
	require_once '../control/conexao.php';

	class LoginControl{
		private $acao;
		private $con;
		function __construct(){

			if(isset($_POST["acao"]))
   		   	 	$this->acao=$_POST["acao"];
			else
           		$this->acao=$_GET["acao"];
            	$this->verificaAcao();
            	

			$o = new Conexao();
			$this->con=$o->conectar();
  		}
			
		function verificaAcao(){
			switch ($this->acao){
				case 1:
					$login = $_POST["login"];
					$senha = $_POST["senha"];
					$dao = new LoginDao();
					$dao->buscaLoginCliente($login,$senha);
				break;
				case 2:
					$login = $_POST["login"];
					$senha = $_POST["senha"];
					$dao = new LoginDao();
					$dao->buscaLoginAdministrador($login,$senha);
				break;
			}
		}
	}
	new LoginControl();
?>