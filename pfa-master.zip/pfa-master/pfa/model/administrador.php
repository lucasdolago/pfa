<?php
class Administrador{
		private $idAdministrador;
		private $email;
		private $login;
		private $senha;

		function setIdAdministrador($id){
			$this->idCliente=$id;
		}

		function setEmail($email){
			$this->email=$email;
		}

		function setLogin($login){
			$this->login=$login;
		}

		function setSenha($senha){
			$this->senha=$senha;
		}



		function getIdAdministrador(){
			return $this->id;
		}

		function getEmail(){
			return $this->email;
		}

		function getLogin(){
			return $this->login;
		}

		function getSenha(){
			return $this->senha;
		}

	}

?>