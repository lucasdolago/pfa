<?php
	require_once '../model/tenis.php';
	require_once '../dao/tenisDao.php';
	require_once '../control/conexao.php';

	class TenisControl{
		private $acao;
		private $con;
		function __construct(){

			if(isset($_POST["acao"]))
   		   	 	$this->acao=$_POST["acao"];
			else
           		$this->acao=$_GET["acao"];
            	$this->verificaAcao();
            	

			$o = new Conexao();
			$this->con=$o->conectar();
  		}
			
		function verificaAcao(){
			switch ($this->acao){
				case 1:
					$t=new Tenis();
					$t->setMarca($_POST["marca"]);
					$t->setModelo($_POST["modelo"]);
					$t->setNumeracao($_POST["numeracao"]);
					$t->setCor($_POST["cor"]);
					$t->setPreco($_POST["preco"]);
					$t->setDescricao($_POST["descricao"]);
					$t->setNomeFoto($_FILES["foto"]["name"]);
					$t->setGenero($_POST["genero"]);
					$dao = new TenisDao();
					$dao->inserir($t);
				break;
				case 2:
					$m = $_GET["m"];
					$n = $_GET["n"];
					$c = $_GET["c"];
					$dao = new TenisDao();
					$dao->Filtra($m,$n,$c);
					//header('Location: ../view/buscaGeral.php');
				break;
			}
		}
	}
	new TenisControl();
?>