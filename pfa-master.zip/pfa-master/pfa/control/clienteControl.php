<?php
	require_once '../model/cliente.php';
	require_once '../dao/clienteDao.php';

	class ClienteControl{
		private $acao;
		function __construct(){
			$this->acao=$_POST["acao"];
			$this->verificaAcao($this->acao);
		}
		function verificaAcao($acao){
			switch ($acao){
				case 1:
					$c=new Cliente();
					$c->setNome($_POST["nome"]);
					$c->setEndereco($_POST["endereco"]);
					$c->setEmail($_POST["email"]);
					$c->setLogin($_POST["login"]);
					$c->setSenha($_POST["senha"]);
					$dao = new ClienteDao();
					$dao->inserir($c);
				break;
			}
		}
	}
	new ClienteControl();
?>