<?php 
	require_once '../control/conexao.php';
	
	class TenisDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}
		function inserir(Tenis $t){
			$marca=$t->getMarca();
			$modelo=$t->getModelo();
			$numeracao=$t->getNumeracao();
			$cor=$t->getCor();
			$preco=$t->getPreco();
			$descricao=$t->getDescricao();
			$nomeFoto=$t->getNomeFoto();
			$genero=$t->getGenero();

			$sql="insert into tenis (marca,modelo,numeracao,cor,preco,descricao,nomeFoto,genero) values('".$marca."','".$modelo."','".$numeracao."','".$cor."','".$preco."','".$descricao."','".$nomeFoto."','".$genero."')";
			echo "Tenis inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}

		function ListaGeral(){
			$dados=null;
			$sql="select * from tenis order by idTenis asc";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}				
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}

		function Filtra($m,$n,$c){
			$dados=null;
			$vet=[];
			$sql= "select * from tenis where cor='".$c."' and marca='".$m"' and numeracao='".$n"'";
			try{
				$query=mysqli_query($this->con, $sql);
				$i=0;
				while($dados=mysqli_fetch_array($query)){
					$vet[$i]=$dados;
					$i++;
				}				
			}catch (mysqli_sql_exception $e){
				echo "Erro de SELECT <hr>".$e->getMessage();
			}
			return $vet;
		}


	}

?>