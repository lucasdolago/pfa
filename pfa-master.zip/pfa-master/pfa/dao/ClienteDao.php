<?php 
	require_once '../control/conexao.php';
	class ClienteDAO{
		private $con;
		function __construct(){
			$o = new Conexao();
			$this->con=$o->conectar();
		}
		function inserir(Cliente $c){
			$nome=$c->getNome();
			$endereco=$c->getEndereco();
			$email=$c->getEmail();
			$login=$c->getlogin();
			$senha=$c->getsenha();

			$sql="insert into cliente (nome,endereco,email,login,senha) values('".$nome."','".$endereco."','".$email."','".$login."','".$senha."')";
			//echo "Cliente inserido com sucesso.";
			try{
				mysqli_query($this->con, $sql)or die(mysqli_error($this->con));
			}catch(mysqli_sql_exception $e){
				echo "Erro ao inserir dados no banco<hr>".$e->getMessage();
			}
		}
	}
?>
