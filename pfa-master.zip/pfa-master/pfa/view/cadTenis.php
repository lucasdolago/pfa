<html>
	<head>
	<title>Cadastro de Tênis</title>
	</head>
<body>
	<h2>Cadastro de Tênis</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/tenisControl.php">
	Marca: <input type="text" name="marca"><br><br>
	Modelo: <input type="text" name="modelo"><br><br>
	Numeração: <input type="number" name="numeracao"><br><br>
	Cor: <input type="text" name="cor"><br><br>
	Preço: <input type="number" name="preco"><br><br>
	Descrição: <input type="text" name="descricao"><br><br>
	Gênero: <input type="text" name="genero"><br><br>
	Foto: <br><input type="file" name="foto"><br><br>
	<input type="submit" name="Cadastrar">
	<input type="hidden" name="acao" value="1">
</form>
</body>
</html>

