<!DOCTYPE html>
<html>
<head>
	<title>Busca Geral</title>
	<meta charset="UTF-8">
	<script>
		function filtrar(m,n,c) {
		    if (str == "") {
		        document.getElementById("tenis").innerHTML = "";
		        return;
		    } else { 
		        if (window.XMLHttpRequest) {
		            // code for IE7+, Firefox, Chrome, Opera, Safari
		            xmlhttp = new XMLHttpRequest();
		        } else {
		            // code for IE6, IE5
		            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		        }
		        xmlhttp.onreadystatechange = function() {
		            if (this.readyState == 4 && this.status == 200) {
		                document.getElementById("tenis").innerHTML = this.responseText;
		            }
		        };
		        xmlhttp.open("GET","../control/tenisControl.php?acao=2&m="+m+"&n="+n+"&c="+c,true);
		        xmlhttp.send();
    }
}

function click(){
	var m = document.getElementById("selectMarca").value;
	var n = document.getElementById("selectNumeracao").value;
	var c = document.getElementById("selectCor").value;

	filtrar(m,n,c);
}

	</script>
</head>
<body>
<form name= "cadastro">
	<select name="selectMarca">
		<?php
			require_once '../dao/TenisDao.php';
	        $o=new TenisDAO();
	        $dados=$o->ListaGeral();
	         foreach ($dados as $marca)
	         	echo "<option value='".$marca["idTenis"]."'>".
	         	$marca["marca"]."</option>";
		?>
	</select>
	<select name="selectNumeracao">
		<?php
			require_once '../dao/TenisDao.php';
	        $o=new TenisDAO();
	        $dados=$o->ListaGeral();
	         foreach ($dados as $numeracao)
	         	echo "<option value='".$numeracao["idTenis"]."'>".
	         	$numeracao["numeracao"]."</option>";
		?>
	</select>
	<select name="selectCor">
		<?php
			require_once '../dao/TenisDao.php';
	        $o=new TenisDAO();
	        $dados=$o->ListaGeral();
	         foreach ($dados as $cor)
	         	echo "<option value='".$cor["idTenis"]."'>".
	         	$cor["cor"]."</option>";
		?>
	</select>
	<input type="button" name="Filtrar" value="Filtrar" onclick="click()">
	<!--<input type="hidden" name="acao" value="2">-->
	</form>
	<br> <br>
	<div id="tenis">Here</div>
</body>
</html>