<html>
	<head>
	<title>Cadastro de Cliente</title>
	</head>
<body>
	<h2>Cadastro de Cliente</h2>
<form name= "cadastro" method="post" enctype="multipart/form-data" action="../control/clienteControl.php">
	Nome: <input type="text" name="nome"><br><br>
	Endereço: <input type="text" name="endereco"><br><br>
	Email: <input type="email" name="email"><br><br>
	Login: <input type="text" name="login"><br><br>
	Senha: <input type="password" name="senha"><br><br>
	<input type="submit" name="Cadastrar">
	<input type="hidden" name="acao" value="1">
</form>
</body>
</html>